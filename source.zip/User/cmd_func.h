#ifndef __cmd_func_H
#define __cmd_func_H
#ifdef __cplusplus
 extern "C" {
#endif
extern float speed_motor ;
extern float angle_steer ;
extern float K_Speed;
extern float K_Angle;
extern int jhsum;
extern int jhangle;
void cmd_hello_func(int argc,char *argv[]);
void cmd_set_servo(int argc,char* argv[]);
void CMD_set_speed_func(int argc,char* argv[]);
void cmd_set_pid_func(int argc,char* argv[]);
void cmd_set_jh(int argc,char* argv[]);
void cmd_set_jh_angle(int argc,char* argv[]);
   
#ifdef __cplusplus
}
#endif
#endif /*__ cmd_func_H */