//QlVQVC1LNjYgbWFkZGV2aWwgNzkzNTU4NzU4QlVQVC1LNjYgbWFkZGV2aWwgNzkzNTU4NzU4
/*!                    �����ʵ��ѧ K66 ѧϰ����
*  �ļ����ƣ�       main.c
*      ���ߣ�       maddevil
*      ˵����       �����ڲ�ѧϰʹ�ã������⴫
*  �ο����ϣ�       ����ѧ�����롢ɽ��K60�⡢����K66ģ�塢����KEAģ��
*    �汾�ţ�       V1.0.0
*  �����£�       2018-12-21 13:41
*/
//QlVQVC1LNjYgbWFkZGV2aWwgNzkzNTU4NzU4QlVQVC1LNjYgbWFkZGV2aWwgNzkzNTU4NzU4


#include "include.h" 
#include "isr.h"
//������

#define  N                     5
#define  FILTER_N              10
#define  AD_CH0               ADC1_SE18
#define  AD_CH1               ADC1_DM0
#define  AD_CH2               ADC1_DP0
#define  AD_CH3               ADC1_SE16
#define  test_port             UART_4                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
#define  g_HighestSpeed        150                     //���������صĶ�ֵ
#define  g_LowestSpeed         0                      //���������صĶ�ֵ
#define  Speed_control_P       250                  //250
#define  Speed_control_I       4                   //4
#define  Speed_control_D       0
//#define  dir_control_P         80                      // 50  
//#define  dir_control_D         250                     // 200
#define START                  ADC1_SE8
#define  LEFT_OR_RIGHT         1//1���� 2����


int     dianya_value = 0;       


/*******************************����*****************************************/
int    dir_control_P = 67, dir_control_D = 300; 
float  Set_speed_l=120.0,Set_speed_r=120;                             //120

int jhsum=5300,jhangle=6000;
/****************************************************************************/


int     ADresult0=0,ADresult1=0,ADresult2=0,ADresult3=0;

int     motor_left_pulse=0 , motor_right_pulse=0;
int     pulse[2];
int     car_speed=0,left_speed=0,right_speed=0;
float   speed_P_value_l=0,speed_I_value_l=0,speed_D_value=0,speed_P_value_r=0,speed_I_value_r=0;

float   speed_error_l=0,last_speed_error_l=0,pre_speed_error=0;
float   speed_controlout_l=0; 
float   speed_error_r=0,last_speed_error_r=0;
float   speed_controlout_r=0; 

float   dir_error=0,last_dir_error=0;
float   dir_P_value=0,dir_D_value=0;
float   direction_controlout=0;
int     left_motordead = 2350, right_motordead = 2200;                     //2350   2200
float   left_motorout=0,right_motorout=0;

int     flag=0,flag1=0,flag2=0,lastflag=0,time=0,jhtime=0;                   //�Ƿ���뻷��

int     sendflag=0,distance=0,leaveflag=0,cntt=0,leaveroadflag=0;
int     leaveflagnum[10];

int     FLAG = 0;
int    result1=0,result2=0,result3=0,result4=0;

uint16   dianya=0;

int     starttime=0;

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//�˲�

int Filter(ADCn_Ch_e adcn_ch, ADC_nbit bit) {
  int     i, j;
  int     filter_temp, filter_sum = 0;
  int     filter_buf[FILTER_N];
  for(i = 0; i < FILTER_N; i++) {
    filter_buf[i] = adc_once( adcn_ch, bit);
  }
  // ����ֵ��С�������У�ð�ݷ���
  for(j = 0; j < FILTER_N - 1; j++) {
    for(i = 0; i < FILTER_N - 1 - j; i++) {
      if(filter_buf[i] > filter_buf[i + 1]) {
        filter_temp = filter_buf[i];
        filter_buf[i] = filter_buf[i + 1];
        filter_buf[i + 1] = filter_temp;
      }
    }
  }
  for(i = 1; i < FILTER_N - 1; i++) filter_sum += filter_buf[i];
  return filter_sum / (FILTER_N - 2);
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//�ٶȻ�PID
void speed_control_l()
{
  //Set_speed=g_HighestSpeed-(ADresult0-ADresult1)*(ADresult0-ADresult1)*(g_HighestSpeed - g_LowestSpeed)/46656;//46656
  car_speed=(motor_left_pulse-motor_right_pulse)/2;
  speed_error_l=car_speed-Set_speed_l;
  speed_P_value_l=(speed_error_l-last_speed_error_l)*Speed_control_P; 
  speed_I_value_l=speed_error_l*Speed_control_I;
  //D_value=(speed_error+pre_speed_error-2*last_speed_error);
  if(speed_controlout_l>7600) speed_controlout_l=7600;
  else speed_controlout_l+=speed_P_value_l+speed_I_value_l;
  last_speed_error_l=speed_error_l;
  //speed_controlout=P_value+I_value+D_value;
}

void speed_control_r()
{
  //Set_speed=g_HighestSpeed-(ADresult0-ADresult1)*(ADresult0-ADresult1)*(g_HighestSpeed - g_LowestSpeed)/46656;//46656
  car_speed=(motor_left_pulse-motor_right_pulse)/2;
  speed_error_r=car_speed-Set_speed_r;
  speed_P_value_r=(speed_error_r-last_speed_error_r)*Speed_control_P; 
  speed_I_value_r=speed_error_r*Speed_control_I;
  //D_value=(speed_error+pre_speed_error-2*last_speed_error);
  if(speed_controlout_r>7600) speed_controlout_r=7600;
  else speed_controlout_r+=speed_P_value_r+speed_I_value_r;
  last_speed_error_r=speed_error_r;
  //speed_controlout=P_value+I_value+D_value;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//����PID
void direction_control()
{   
  dir_error=(ADresult0)-ADresult1;
  dir_P_value=dir_control_P*dir_error;
  dir_D_value=dir_control_D*(dir_error-last_dir_error);
  //if(dir_D_value>4500)dir_D_value=4500;
  direction_controlout=dir_P_value+dir_D_value; 
  //if(direction_controlout>7600) direction_controlout=7600;
  last_dir_error=dir_error;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//���PWM���
void motorout()    
{
  left_motorout=left_motordead-(0.5*speed_controlout_l)-direction_controlout;
  right_motorout=right_motordead-(0.5*speed_controlout_r)+direction_controlout;
  PWMSetMotor2((s32)left_motorout,(s32)right_motorout);  
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//PIT�жϷ�����
void PIT0_ISR()
{
  static int time_count = 0;
  static int time_count_flag = 0;
  
  if(time_count_flag == 1)
    time_count++;
  
  PIT_Flag_Clear(PIT0);//���жϱ�־λ
  ADresult0    =   Filter(AD_CH0, ADC_12bit);      
  ADresult1    =   Filter(AD_CH1, ADC_12bit);
  ADresult2    =   Filter(AD_CH2, ADC_12bit);
  ADresult3    =   Filter(AD_CH3, ADC_12bit);
  //uart_printf(test_port,"��AD:%d\n��AD:%d\n\n", ADresult0,ADresult1);
  int16 ware[7];
  ware[0]=ADresult0;
  ware[1]=ADresult1;
  ware[2]=ADresult2;
  ware[3]=ADresult3;
  
  motor_left_pulse = ftm_quad_get(FTM1);
  motor_right_pulse = ftm_quad_get(FTM2);
  //uart_printf(test_port,"%d\n", ADresult0+ADresult1);
  //uart_printf(test_port,"�����壺%d\n������:%d\n\n",motor_left_pulse,motor_right_pulse );    
  ware[4]=motor_left_pulse;
  ware[5]=-motor_right_pulse;
  ware[6]=ADresult0+ADresult1;
  uart_sendware(test_port,&ware,sizeof(ware));
  ftm_quad_clean(FTM1);
  ftm_quad_clean(FTM2);
  dianya = Filter(START, ADC_12bit);
  //uart_printf(test_port,"%d\n",(dianya));
  //uart_printf(test_port,"%d       %d\n", left_motorout, right_motorout);
  
  
  if(result2) 
  {
    //uart_printf(test_port,"12V");
    dianya_value=3600;      //12v
  }
  else if(result2 == 0) 
  {
    //uart_printf(test_port,"11V");
    dianya_value=3300;     //11v
  }
  if(result1)                     //�Զ�����
  { 
    //uart_printf(test_port,"�Զ�����");
    if(dianya>dianya_value)     
    {  
      FLAG = 1;
    }
    if(FLAG == 1)
    {
      if(starttime<50)
      {
        starttime++;
        dir_control_P = 30;
        speed_control_l();
        speed_control_r();
        direction_control();
        motorout(); 
      }
      /************************************����1******************************/
      /*if(ADresult0+ADresult1>5300) 
      {
      flag=1;
    }
      if(flag==1&&ADresult0+ADresult1<5300)
      {
      flag=0;
    }
      lastflag=flag;
      if(flag==1&&lastflag==0)
      {
      flag1=1;
    }else flag1=0;
      if(flag==0&&lastflag==1)
      {
      flag2=1;
    }else flag2=0;
      if(flag1 == 1&&flag2 == 1)
      {
      time_count_flag = 1;  
      time++;
    }
      if(time_count < 20 && time == 1)
      {
      //uart_printf(test_port,"first!\r\n");
      speed_control_l();
      speed_control_r();
      if(LEFT_OR_RIGHT == 1)
      direction_controlout=-6000;
      else if(LEFT_OR_RIGHT == 2)
      direction_controlout=6000;
      
      motorout();
    }else if(time_count==20)
      {
      flag1=0;
      flag2=0;
      time_count=0;
      time_count_flag=0;
    }else if(time_count < 20 && time == 2)
      {
      //uart_printf(test_port,"second!\r\n");
      speed_control_l();
      speed_control_r();
      direction_controlout=0;
      
      motorout();
    }
      else
      { 
      speed_control_l();
      speed_control_r();
      direction_control();
      motorout(); 
    }     
      */
      else
      {
        if(result3 == 0)
        {
          //uart_printf(test_port,"����");
          if(ADresult0+ADresult1>jhsum) 
          {
            time_count_flag = 1;  
            static int time = 0;
            if(time_count < 100 && time == 0)
            {
              //uart_printf(test_port,"first!\r\n");
              speed_control_l();
              speed_control_r();
              if(LEFT_OR_RIGHT == 1)
                direction_controlout=-jhangle;
              else if(LEFT_OR_RIGHT == 2)
                direction_controlout=jhangle;
              
              motorout();
            }else if(time_count > 100 || time == 2)//�ڶ��ν�
            {
              time = 2;
              speed_control_l();
              speed_control_r();
              direction_controlout=0;
              motorout();     
              //uart_printf(test_port,"second!\r\n");
              time_count = 0;
              time_count_flag = 0;
            }
          }
        }
        else
        {
          //uart_printf(test_port,"������");
          speed_control_l();
          speed_control_r();
          direction_control();
          motorout(); 
        }
      }
    }
  }
  else if(result1 == 0)
  { 
    if(result3 == 0)
    {
      //uart_printf(test_port,"����");
      if(ADresult0+ADresult1>jhsum) 
      {
        time_count_flag = 1;  
        static int time = 0;
        if(time_count < 100 && time == 0)
        {
          //uart_printf(test_port,"first!\r\n");
          speed_control_l();
          speed_control_r();
          if(LEFT_OR_RIGHT == 1)
            direction_controlout=-jhangle;
          else if(LEFT_OR_RIGHT == 2)
            direction_controlout=jhangle;
          
          motorout();
        }else if(time_count > 100 || time == 2)//�ڶ��ν�
        {
          time = 2;
          speed_control_l();
          speed_control_r();
          direction_controlout=0;
          motorout();     
          //uart_printf(test_port,"second!\r\n");
          time_count = 0;
          time_count_flag = 0;
          
        }
      }
    }
    else
    {
      //uart_printf(test_port,"������");
      speed_control_l();
      speed_control_r();
      direction_control();
      motorout(); 
    }
  }
}




//#if -#elif -#endif  ��Ԥ������� 1��ʾҪ���������
#if 1
void main()
{
  DisableInterrupts;  
  pit_init(PIT0, 50);
  uart_init(test_port, 115200); 
  adc_init(AD_CH0);
  adc_init(AD_CH1);
  adc_init(AD_CH2);
  adc_init(AD_CH3);
  adc_init(START);
  ftm_quad_init(FTM1);
  ftm_quad_init(FTM2);
  motor_init();
  pit_irq_en(PIT0); 
  gpio_init(PTA5,GPI,0);
  gpio_init(PTA16,GPI,0);
  gpio_init(PTA17,GPI,0);
  gpio_init(PTA14,GPI,0);
  uart_rx_irq_en(UART_4);
  cmd_init();
  EnableInterrupts;
  while(1)
  {
    usart_exc();
    result1 = gpio_get(PTA5);  
    result2 = gpio_get(PTA16);
    result3 = gpio_get(PTA17);
    result4 = gpio_get(PTA14);
  }
}
#elif 0  
//��ֱ��

void main()
{
  DisableInterrupts;  
  motor_init();
  PWMSetMotor2(2350,2200);
  EnableInterrupts;
  while(1)
  {}  
}
#elif 0
//ģ�⡢����ת���� ADC
#define AD_CH   ADC1_DM0
void main()
{
  DisableInterrupts;  
  uart_init(test_port, 115200);
  // adc_init(AD_CH);
  
  EnableInterrupts;
  while(1)
  {
    uart_printf(test_port, "ADC ����\n");
    /*adResult8 = adc_once(AD_CH, ADC_8bit);     //ͨ��drivers_cfg.h�ҵ�����E0��Ӧ��ADC��Դ ��ADC1_AD4a
    adResult10 = adc_once(AD_CH, ADC_10bit);
    adResult16 = adc_once(AD_CH, ADC_16bit);
    uart_printf(test_port, "10λת����0~1023): %d\n16λת����0~65535): %d\n\n",adResult8,adResult10,adResult16);
    delayms(500);*/
  }
}

#elif 0                                           
//���Գ�����

void main()
{
  DisableInterrupts;           //�ر��ж�
  uart_init(test_port, 115200);
  gpio_init(TRIG,GPO,0);
  gpio_init(ECHO,GPI,0);
  EnableInterrupts;
  
  while(1)
  {
    gpio_set(TRIG,1);               //������������
    pit_delay_us(PIT1,20);        
    gpio_set(TRIG,0);           //����һ��20us�ĸߵ�ƽ����
    
    
    while(gpio_get (ECHO) == 0);             //�ȴ���ƽ��ߣ��͵�ƽһֱ�ȴ�
    pit_time_start  (PIT1); //��ʼ��ʱ
    while(gpio_get(ECHO) == 1);              //�ȴ���ƽ��ͣ��ߵ�ƽһֱ�ȴ�
    
    uint32 timevar = pit_time_get(PIT1);    //ֹͣ��ʱ����ȡ��ʱʱ��
    pit_close(PIT1);
    timevar = timevar * 340 /2800000;
    //timevar = timevar*(331.4+0.607*10)/20000000;  //�����¶Ȳ���
    delayms(100);
    uart_printf(test_port,"������%d\n",timevar);
  }  
}


#elif 0
//���������������  FTMģ��
void main()
{  
  DisableInterrupts;  
  uart_init(test_port, 115200);
  uart_printf(test_port, "�ڹܽ�C1���Ƶ��Ϊ 1kHz\n,
              ռ�ձ�Ϊ30%�ķ�������ʾ�����۲�");
                ftm_pwm_init(FTM0, FTM_CH0, 100, 3000);
              delayms(10000);
              ftm_pwm_freq(FTM0, 50);
              //������Ƶ����ռ�ձ����εĺ�����ע�������FTM.c
              EnableInterrupts;
              while(1)
              {
              }
}
#elif 0
              //�ⲿ�ж� EXTI
              void main()
              {
                DisableInterrupts;  
                uart_init(test_port, 115200);
                uart_printf(test_port, "EXTI ����\n");
                
                //��ʼ��
                exti_enable(PTE0,IRQ_FALLING|PULLUP);//�½��ش������ڲ���������port.h��
                EnableInterrupts;
                while(1)
                {
                }
              }
#elif 0
              //�ڲ���ʱ�ж�  PIT
              void main()
              {
                DisableInterrupts;  
                uart_init(test_port, 115200);
                uart_printf(test_port, "PIT����\n");
                
                //��ʼ��PIT0 ,  2Hz  
                //0.5s����һ���ж�
                pit_init(PIT0, 2);               //�����ж϶�һ������main������ʼ������isr.h isr.c�����Ͷ���
                //ʹ��PIT  ����ʹ��PITʱ��ش�ʹ��
                pit_irq_en(PIT0);
                
                EnableInterrupts;
                while(1)
                {
                  
                }
              }
#elif 0
              //�������  TPM��LPTMRģ��
              void main()
              {  
                DisableInterrupts;  
                uart_init(test_port, 115200);
                uart_printf(test_port, "�����������:\n");
                ftm_pwm_init(FTM0, FTM_CH0, 500, 3000);//������pwm
                tpm_pulse_init(TPM1,TPM_CLKIN0);
                tpm_pulse_init(TPM2,TPM_CLKIN1);
                LPTMR_Pulse_Init(LPT0_ALT1,32768,LPT_Rising);
                //������Ƶ����ռ�ձ����εĺ�����ע�������FTM.c
                EnableInterrupts;
                while(1)
                {
                  int a=tpm_pulse_get(TPM1);
                  int b=tpm_pulse_get(TPM2);
                  int c=LPTMR_Pulse_Get();    
                  LPTMR_Pulse_Clean();
                  tpm_pulse_clean(TPM1)
                    tpm_pulse_clean(TPM2);
                  pit_delay(PIT0,bus_clk_M*1000000);
                  uart_printf(test_port, "%d %d %d\n",a,b,c);
                }
              }
#elif 0
              //�����ж�  UART_IRQ
              void main()
              {
                DisableInterrupts;
                uart_init(test_port, 115200);
                uart_rx_irq_en(test_port);    //�����ж�
                EnableInterrupts;
                while(1)
                {}
              }
#elif 0
              //���ڻ��淢�� uart_sendbuffer
              void main(void)
              {
                DisableInterrupts;        //�ر����ж�
                
                pit_init(PIT0, 100);      
                uart_init  (test_port,9600);       
                uart_sendbuffer_enable(test_port);  //�������ͻ��棨��ϸ˵����UART.C��
                EnableInterrupts;  
                pit_irq_en(PIT0);
                int16 i=0;
                while(1)
                {
                  ++i;
                  delayms(1);
                }
              }
#endif