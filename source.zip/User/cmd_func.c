#include "cmd_func.h"
#include "include.h"

float speed_motor = 2600;
float angle_steer = 2600;
float K_Speed = 1.5;
float K_Angle = 1.5;
extern int dir_control_P,dir_control_D; 
/**
  * @brief  cmd hello����
  * @retval none
  */
void cmd_hello_func(int argc,char* argv[])
{
  uart_printf(UART_4,"hello world");
    //uprintf(UART_1,"hello world");
}

/**
  * @brief  cmd_set_servo����
  * @retval none
  */
void cmd_set_servo(int argc,char* argv[])
{
    K_Speed = atof(argv[1]);
    K_Angle = atof(argv[2]);
    uart_printf(UART_1,"%f  %f\r\n",K_Speed,K_Angle);
}

void CMD_set_speed_func(int argc,char* argv[])//set_speed 1000 2000 1000
{
   uprintf(UART_4,"%d  %d\r\n",atoi(argv[1]),atoi(argv[2]));
}

void cmd_set_pid_func(int argc,char* argv[])//pid 0.5 80
{
  dir_control_P = atoi(argv[1]);
  dir_control_D = atoi(argv[2]);
  uprintf(UART_4,"%d  %d\r\n",dir_control_P,dir_control_D);
}
    
void cmd_set_jh(int argc,char* argv[])//jh 5300
{
  jhsum = atoi(argv[1]);
  uprintf(UART_4,"%d \r\n", jhsum);
}

void cmd_set_jh_angle(int argc,char* argv[])//angle 6000
{
  jhangle = atoi(argv[1]);
  uprintf(UART_4,"%d \r\n", jhangle);
}